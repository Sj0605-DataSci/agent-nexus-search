# Privacy Practices

## Permission Justifications

### Host Permissions

- `https://*.discoverminds.ai/*`: Required to communicate with our API server for searching and retrieving user profiles.

### Storage Permission

- Used to store user preferences and authentication tokens locally
- Caches frequently accessed data to improve performance

### Notifications Permission

- Sends notifications when new relevant connections are found
- Alerts users about important updates or messages

### Remote Code

- No external code is loaded dynamically
- All code is packaged within the extension

## Single Purpose Description

Discover Minds is designed specifically for professional networking and expertise discovery, helping users find and connect with relevant professionals based on their expertise and background.

## Data Usage & Collection

- We collect only necessary data for the functioning of the search and recommendation features
- All data collection complies with Chrome Web Store policies
- No personal data is shared with third parties
- Users can request data deletion at any time
